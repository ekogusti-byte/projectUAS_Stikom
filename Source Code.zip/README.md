# Tugas UAS Mobile Programming

Ini adalah project yang akan dikumpulkan sebagai salah satu syarat ketuntasan mata kuliah Mobil Programming pada semester 5 di kelas malam S1 Teknik Informatika STIKOM PGRI Banyuwangi

## Getting Started

Aplikasi ini di compile dengan Android Studio menggunakan Flutter.
